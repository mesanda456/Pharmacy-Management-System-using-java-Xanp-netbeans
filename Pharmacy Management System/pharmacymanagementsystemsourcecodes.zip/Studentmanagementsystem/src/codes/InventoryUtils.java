/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package codes;

/**
 *
 * @author DELL
 */
public class InventoryUtils {

    public static String billpath = "C:\\Users\\DELL\\Music";

}
