
package codes;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

 
public class DBconnect {
    private static Connection conn;

    public static Connection connect() {
        try {
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Establish connection
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmacy","root","");
            System.out.println("Connected");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println(e.getMessage());
        }
        return conn;
    }
    
}
